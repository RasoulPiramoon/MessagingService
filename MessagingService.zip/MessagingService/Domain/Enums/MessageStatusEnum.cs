﻿namespace Core.Enums
{
    public enum MessageStatusEnum
    {
        New = 0,
        Sent = 1,
        Failed = 2
    }
}
