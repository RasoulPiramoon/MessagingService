﻿namespace Core.Enums
{
    public enum MessageTypeEnum
    {
        SMS = 1,
        Email = 2

    }
}
